from pathlib import Path
import json,requests,hashlib,subprocess
from urllib.parse import quote
r=Path('/downloads/udecs-music8');r.mkdir(exist_ok=True)
tracks=[('Upbeat/Advertime', 'Rafael Krux', 'https://creazilla.com/media/audio/7956959/advertime'), ('Upbeat/Funshine', 'Kevin MacLeod', 'https://creazilla.com/media/audio/7956963/funshine'), ('Upbeat/Inspiration', 'Rafael Krux', 'https://creazilla.com/media/audio/7956965/inspiration'), ('Upbeat/Inventing Flight', 'Bryan Teoh', 'https://creazilla.com/media/audio/7956966/inventing-flight'), ('Upbeat/Motions', 'Rafael Krux', 'https://creazilla.com/media/audio/7956968/motions'), ('Upbeat/Pickled Pink', 'Kevin MacLeod', 'https://creazilla.com/media/audio/7956969/pickled-pink'), ('Upbeat/Screen Saver', 'Kevin MacLeod', 'https://creazilla.com/media/audio/7956971/screen-saver'), ('Upbeat/Ukulele Song', 'Rafael Krux', 'https://creazilla.com/media/audio/7956974/ukulele-song'), ('Electronic/Beat Thee', 'Alexander Nakarada', 'https://creazilla.com/media/audio/7957154/beat-thee'), ('Upbeat/Stereotype News', 'Rafael Krux', 'https://creazilla.com/media/audio/7956972/stereotype-news')]
a=[]
for path,author,source in tracks:
 name=path.split('/')[-1];api='https://api.github.com/repos/0lhi/FreePD/contents/'+quote(path+'.mp3')+'?ref=stream';j=requests.get(api,timeout=30).json();u=j['download_url'];p=r/(name+'.mp3');p.write_bytes(requests.get(u,timeout=40).content);wav=r/(name+'-16s.wav');subprocess.run(['ffmpeg','-v','error','-y','-ss','8','-stream_loop','-1','-i',str(p),'-t','16','-af','volume=0.35,afade=t=in:d=0.6,afade=t=out:st=14.8:d=1.2',str(wav)],check=True)
 a.append(dict(track=name,author=author,author_source=source,archive_api=api,download_url=u,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),license='CC0 1.0',license_url='https://raw.githubusercontent.com/0lhi/FreePD/stream/LICENSE',audio_preview=str(wav)));print(name,flush=True)
json.dump(a,open(r/'provenance.json','w'),indent=2)

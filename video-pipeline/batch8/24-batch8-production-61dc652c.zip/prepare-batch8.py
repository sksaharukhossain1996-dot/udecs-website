from pathlib import Path
import json
r=Path('/downloads/udecs-batch8');by={g['sku']:g for g in json.load(open(r/'galleries.json'))};music=json.load(open('/downloads/udecs-music8/provenance.json'))
sel={'2766':[4,0,3,6],'2803':[5,0,2,6],'2813':[5,0,4,6],'3040':[1,2,3,4],'3293':[2,4,3,2],'4749':[3,0,2,4],'4797':[3,0,5,6],'4946':[4,0,1,5],'4963':[4,1,3,5],'4998':[4,0,3,6]}
names=['Thumb cutter set','Hand-press slicer','Cordless whisk','Folding fruit basket','Butterfly wings set','Car cleaning duster','Chair phone stand','Spray glass cleaner','Washer door holder','Rainbow keychain']
meta=[]
for ix,((code,ids),name) in enumerate(zip(sel.items(),names)):
 g=by[code];imgs=[g['images'][i].copy()for i in ids]
 special={'2766':'Sharp blade / handle with care','2803':'Sharp parts / handle with care','3293':'Colour aur set contents confirm karein','4797':'Colour aur phone fit confirm karein','4963':'Surface aur machine fit confirm karein'}.get(code,'Size aur contents order se pehle confirm karein')
 scenes=[(imgs[0]['path'],name+'.\nCloser look.',name+' / SKU '+code),(imgs[1]['path'],'Design ko\nkareeb se dekho.','Supplier gallery / product view'),(imgs[2]['path'],'Ek aur\nproduct view.',special),(imgs[3]['path'],'Details\ncheck karein.','Supplier catalog photo / not a working demo'),(imgs[0]['path'],'Details chahiye?','udecs.store par final availability aur quote poochhein')]
 src=Path('/tmp/base-render.py').read_text().replace("root='/downloads/vacuum-upgrade/'",f"root='{r}/'");st=src.index('scenes=');en=src.index('\nlogo=',st);src=src[:st]+'scenes='+repr(scenes)+src[en:];src=src.replace('/downloads/image-96f79ff6.jpg','/downloads/recovered-original-logo.png').replace('Image.open(root+name)','Image.open(name)').replace('0390-multi-image-upgraded-sample.mp4',f'{code}-upgraded.mp4').replace('/downloads/udecs-reel-test/music-preview.wav',music[ix]['audio_preview']);(r/f'{code}-render.py').write_text(src)
 desc=f'{name} ka multi-image supplier-gallery preview. Size, colour, contents aur final availability/quote order se pehle confirm karein. Ye working demo ya tested-performance claim nahi hai.'
 if code in ['2766','2803']:desc+=' Sharp parts ko care se handle karein.'
 if code=='3293':desc+=' Gallery mein alag colours dikhaye gaye hain; exact colour aur contents confirm karein.'
 if code=='4963':desc+=' Machine aur surface compatibility confirm karein. Mold-prevention result ka claim nahi hai.'
 desc+='\n\nWebsite: https://udecs.store/\nCustomer inquiry WhatsApp: +91 86605 80564\nProduct details aur final order terms order se pehle confirm karein.\n\nMusic: '+music[ix]['track']+' by '+music[ix]['author']+' (FreePD archive, CC0 1.0).\n#UDECS #ProductSpotlight #Shorts'
 meta.append(dict(sku=code,product_id=g['product']['id'],catalog_title=g['product']['name'],batch=8,title=name+' | UDECS Product Spotlight #Shorts',description=desc,fb_instagram_caption=desc,video=f'{code}-upgraded.mp4',supplier_page=g['page'],catalog_image=g['product']['imageUrl'],images=imgs,music=music[ix],scenes=[dict(headline=h,subline=s)for p,h,s in scenes],rights_note='Internet supplier image reuse permission unverified. CC0 music documented, not guaranteed Content ID claim-free.',logo_note='Original logo recovered unchanged from existing approved video frame,116x112 pixels'))
json.dump(meta,open(r/'batch8-metadata.json','w'),indent=2)

from PIL import Image,ImageDraw,ImageFont
import subprocess,math,json
root='/downloads/vacuum-upgrade/';f='/skills/platform/files/assets/fonts/';reg=f+'melange-grotesk-350.ttf';bold=f+'melange-grotesk-600.otf';dis=f+'Aime-Light.ttf'
scenes=[('gallery-1.jpg','Compact vacuum.\nCloser look.','Handheld vacuum / SKU 0390'),('gallery-5.jpg','Design ko\nkareeb se dekho.','Supplier gallery / product view'),('gallery-6.jpg','Nozzle view.','Attachments ko order se pehle confirm karein'),('gallery-2.jpg','Kit ki\ndetails dekho.','Supplier catalog photo / not a working demo'),('gallery-1.jpg','Details chahiye?','udecs.store par final availability aur quote poochhein')]
logo=Image.open('/downloads/image-96f79ff6.jpg').convert('RGB');logo.thumbnail((116,112))
bases=[];photos=[]
for name,head,sub in scenes:
 im=Image.new('RGB',(720,1280),'white');d=ImageDraw.Draw(im)
 im.paste(logo,(38,35))
 def text(x,y,t,size,font=reg,color='#193956'):d.multiline_text((x,y),t,font=ImageFont.truetype(font,size),fill=color,spacing=9)
 text(187,58,'UDECS',36,bold);text(188,108,'PRODUCT SPOTLIGHT',18,reg)
 text(40,906,head,55,dis)
 line='';lines=[]
 for w in sub.split():
  nx=(line+' '+w).strip()
  if d.textlength(nx,font=ImageFont.truetype(reg,27))>620:lines.append(line);line=w
  else:line=nx
 lines.append(line);text(40,1053,'\n'.join(lines),27,reg,'#585254')
 d.line((40,1155,680,1155),fill='#D39A38',width=3);text(40,1177,'udecs.store',32,bold)
 d.rectangle((0,0,719,1279),outline='#193956',width=12);d.line((30,23,690,23),fill='#D39A38',width=3);d.line((30,1252,690,1252),fill='#D39A38',width=3)
 bases.append(im);photos.append(Image.open(root+name).convert('RGB'))
out=root+'0390-multi-image-upgraded-sample.mp4'
p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','720x1280','-r','25','-i','-','-i','/downloads/udecs-reel-test/music-preview.wav','-map','0:v','-map','1:a','-t','16','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',out],stdin=subprocess.PIPE)
for n in range(400):
 scene=n//80;t=(n%80)/79;im=bases[scene].copy();photo=photos[scene].copy();size=620+int(40*t);photo.thumbnail((size,size),Image.Resampling.LANCZOS);px=(720-photo.width)//2;py=205+(660-photo.height)//2
 # Brief horizontal reveal; never invent a new product angle.
 offset=int((1-min(t/0.15,1))**2*80)*(1 if scene%2==0 else -1)
 well=Image.new('RGB',(640,660),'white');well.paste(photo,(px+offset-40,py-205));im.paste(well,(40,205));p.stdin.write(im.tobytes())
p.stdin.close();assert p.wait()==0
print(out)

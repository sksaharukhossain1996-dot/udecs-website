from pathlib import Path
from PIL import Image
import json,subprocess,io,hashlib
r=Path('/downloads/udecs-batch10');meta=json.load(open(r/'batch10-metadata.json'))
for x in meta:
 v=r/x['video'];sheet=Image.new('RGB',(1620,960),'white')
 for j,t in enumerate([.9,4.1,7.3,10.5,13.7,3.27]):
  b=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(v),'-frames:v','1','-vf','scale=270:480','-f','image2pipe','-vcodec','png','-']);im=Image.open(io.BytesIO(b));sheet.paste(im,(j*270,0))
 # Full resolution detail crops allow footer/logo/text review in addition to overall composition.
 b=subprocess.check_output(['ffmpeg','-v','error','-ss','1','-i',str(v),'-frames:v','1','-f','image2pipe','-vcodec','png','-']);im=Image.open(io.BytesIO(b));sheet.paste(im.crop((0,0,720,180)),(0,500));sheet.paste(im.crop((0,900,720,1280)),(750,500))
 sheet.save(r/f"qa-{x['sku']}.jpg")
 tech=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(v)]));x['technical']={k:tech['format'][k] for k in ['duration','size']};x['technical']['streams']=[{k:s.get(k) for k in ['codec_name','width','height','r_frame_rate','sample_rate','channels']} for s in tech['streams']];x['sha256']=hashlib.sha256(v.read_bytes()).hexdigest()
json.dump(meta,open(r/'batch10-metadata.json','w'),indent=2)

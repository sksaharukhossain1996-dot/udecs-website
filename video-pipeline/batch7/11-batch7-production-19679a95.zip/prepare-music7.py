from pathlib import Path
import json,requests,hashlib,subprocess
from urllib.parse import quote
r=Path('/downloads/udecs-music7');r.mkdir(exist_ok=True)
tracks=[('Electronic/Backbeat','Kevin MacLeod','https://creazilla.com/media/audio/7957151/backbeat'),('Electronic/Beat One','Kevin MacLeod','https://creazilla.com/media/audio/7957153/beat-one'),('Electronic/Arpent','Kevin MacLeod','https://creazilla.com/media/audio/7957152/arpent'),('Miscellaneous/Bass Meant Jazz','Kevin MacLeod','https://creazilla.com/media/audio/7957169/bass-meant-jazz'),('Electronic/Bit Bit Loop','Kevin MacLeod','https://creazilla.com/media/audio/7957155/bit-bit-loop'),('Electronic/Fireworks','Alexander Nakarada','https://creazilla.com/media/audio/7957158/fireworks'),('Electronic/Chronos','Alexander Nakarada','https://creazilla.com/media/audio/7957156/chronos'),('Electronic/Goodnightmare','Kevin MacLeod','https://creazilla.com/media/audio/7957159/goodnightmare'),('Electronic/3 am West End','Kevin MacLeod','https://creazilla.com/media/audio/7957150/3-am-west-end'),('Upbeat/Limit 70','Kevin MacLeod','https://creazilla.com/media/audio/15519470/kevin-macleod---limit-70')]
a=[]
for path,author,source in tracks:
 name=path.split('/')[-1];api='https://api.github.com/repos/0lhi/FreePD/contents/'+quote(path+'.mp3')+'?ref=stream';j=requests.get(api,timeout=30).json();u=j['download_url'];p=r/(name+'.mp3');p.write_bytes(requests.get(u,timeout=40).content);wav=r/(name+'-16s.wav');subprocess.run(['ffmpeg','-v','error','-y','-ss','8','-stream_loop','-1','-i',str(p),'-t','16','-af','volume=0.35,afade=t=in:d=0.6,afade=t=out:st=14.8:d=1.2',str(wav)],check=True)
 a.append(dict(track=name,author=author,author_source=source,archive_api=api,download_url=u,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),license='CC0 1.0',license_url='https://raw.githubusercontent.com/0lhi/FreePD/stream/LICENSE',audio_preview=str(wav)));print(name,flush=True)
json.dump(a,open(r/'provenance.json','w'),indent=2)

import requests,json,re,io
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
r=Path('/downloads/udecs-batch7');r.mkdir(exist_ok=True)
p=json.load(open('/tmp/products.json'));out=[]
for c,n in [('2355',0),('2374',0)]:
 try:
  product=next(x for x in p if x['id'].split('_')[0]==c);url=json.load(open('/tmp/tool-async/s'+c+'b.json'))[n]['url'].split('?')[0];h=requests.get(url,timeout=20).text;canonical=re.search(r'<link[^>]*rel="canonical"[^>]*href="([^"]+)"',h).group(1);j=requests.get(canonical+'.js',timeout=20).json();imgs=[]
  for ix,u in enumerate([product['imageUrl']]+j['images'][:7]):
   u='https:'+u if u.startswith('//') else u
   try:
    data=requests.get(u,timeout=20).content;im=Image.open(io.BytesIO(data)).convert('RGB');path=r/(c+('-store.jpg' if ix==0 else '-g'+str(ix-1)+'.jpg'));im.save(path);imgs.append(dict(url=u,path=str(path)))
   except Exception as e:print(c,ix,'image error',str(e)[:70])
  sh=Image.new('RGB',(200*len(imgs),400),'#eeeeee');d=ImageDraw.Draw(sh)
  for ix,x in enumerate(imgs):
   im=Image.open(x['path']);im.thumbnail((198,350));sh.paste(im,(ix*200+(200-im.width)//2,(350-im.height)//2));d.text((ix*200,370),'STORE' if ix==0 else str(ix-1),fill='black')
  sh.save(r/('match-'+c+'.jpg'));out.append(dict(sku=c,product=product,page=canonical,images=imgs[1:],store=imgs[0]));print(c,canonical,len(imgs),flush=True)
 except Exception as e:print(c,'FAILED',str(e),flush=True)
old=json.load(open(r/'galleries.json'));old=[x for x in old if x['sku'] not in ['2355','2374']];json.dump(old+out,open(r/'galleries.json','w'),indent=2)
